/*
**  Lab 3 - A Stream Extension
**  Matt Lampe
**  M03516707
**  CS4003
**  2/9/2015
*/

package collectorstream;

public class IntObject {
   int number;
   IntObject(int n) { number = n; }
}
